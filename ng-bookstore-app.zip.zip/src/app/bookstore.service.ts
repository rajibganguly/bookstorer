import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class BookstoreService {
  url: string = '/api/dev/DynamoDBManager';
  headers:any = { 
    'Content-Type': 'application/json',
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "OPTIONS,POST,GET,PUT,DELETE"
   }

  constructor(private http: HttpClient) { }

  /**
   * 
   * @returns GET ALL BOOKS
   */
  getAllBooks() {
    return this.http.post(
      this.url,
      JSON.stringify({ "operation": "scan", "payload": {} }),
      {
        headers: this.headers
      }
    )
  }

  /**
   * 
   * @returns GET A SINGLE BOOK
   */
  getASingleBook(bookId: string) {
    return this.http.post(
      this.url,
      JSON.stringify({"operation": "read", "payload": {"Key": {"id": bookId}}}),
      {
        headers: this.headers
      }
    )
  }

  /**
   * 
   * @returns POST A BOOKS
   */
  postAllBooks(book: any) {
    return this.http.post(
      this.url,
      JSON.stringify({"operation": "create", "payload": {"Item": book}}),
      {
        headers: this.headers
      }
    )
  }

  /**
   * 
   * @returns UPDATE A BOOKS
   */
  updateBookDetails(book: any) {
    return this.http.post(
      this.url,
      JSON.stringify({
        "operation": "update",
        "payload": {
            "Key": {
                "id": book.id
            },
            "UpdateExpression": "SET #ttle = :newTtle, #athr = :newAthr",
            "ExpressionAttributeNames": {
                "#ttle": "title",
                "#athr": "author"
            },
            "ExpressionAttributeValues": {
                ":newTtle": book.title,
                ":newAthr": book.author
            }
        }
    }),
      {
        headers: this.headers
      }
    )
  }


  /**
   * 
   * @returns Delete A BOOKS
   */
  deleteSelectedBook(bookId: string) {
    return this.http.post(
      this.url,
      JSON.stringify({"operation": "delete", "payload": {"Key": {"id": bookId}}}),
      {
        headers: this.headers
      }
    )
  }
}
