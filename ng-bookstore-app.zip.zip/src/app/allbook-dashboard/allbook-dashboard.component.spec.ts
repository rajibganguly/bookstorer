import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AllbookDashboardComponent } from './allbook-dashboard.component';

describe('AllbookDashboardComponent', () => {
  let component: AllbookDashboardComponent;
  let fixture: ComponentFixture<AllbookDashboardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AllbookDashboardComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(AllbookDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
